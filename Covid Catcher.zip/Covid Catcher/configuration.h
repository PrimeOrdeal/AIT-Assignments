#pragma once

struct Configuration
{
	bool should_display_ids			= false;
	bool should_display_coordinates = false;
	bool should_display_colliders	= false;

	int window_width	= 800;
	int window_height	= 900;
};