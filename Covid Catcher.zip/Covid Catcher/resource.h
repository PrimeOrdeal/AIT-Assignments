//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Game.rc
//
#define IDR_MENU1                       101
#define IDD_DIALOG1                     102
#define IDD_DIALOG2                     104
#define IDC_BUTTON1                     1001
#define ID_FILE_EXIT                    40001
#define ID_PLAYER_INCREASESPEED         40002
#define ID_PLAYER_DECREASESPEED         40003
#define ID_CREDITS_DEVELOPERS           40004
#define ID_CREDITS_THIRDPARTYLIBS       40005
#define ID_DEBUG_TOGGLEDISPLAYID        40006
#define ID_SKIN_KNIGHT                  40007
#define ID_SKIN_NINJA                   40008
#define ID_SKIN_ZOMBIE                  40009
#define ID_DEBUG_TOGGLECOORDINATES      40010
#define ID_FILE_PAUSE                   40011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40012
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
